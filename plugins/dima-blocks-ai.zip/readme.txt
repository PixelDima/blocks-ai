=== Dima Blocks Ai ===
Contributors:      adeltahri,PixelDima
Tags:              block
Tested up to:      6.2
Stable tag:        0.2.0
License:           GPLv2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Blocks AI is a plugin that allows you to use AI to create blocks for your website.

== Description ==

# Dima Blocks Ai

Welcome to Dima Blocks Ai - the intelligent WordPress plugin that brings the power of OpenAI's ChatGPT to your content creation and editing workflow. 
With Dima Blocks Ai, you can enhance your content with features like grammar and spelling correction, translation to multiple languages, and tonal adjustments. 
You can also summarize text with ease. 
Make your content creation process smarter and more efficient with Dima Blocks Ai!

## Features

- **AI-Powered Text-to-Blocks**: Convert your text to blocks like Notion AI with just a few clicks.
- **Intelligent Blocks**: Create beautiful tables, hero sections, and calls to action with AI-generated content.
- **Text Improvement**: Enhance the quality of your text with AI-driven suggestions.
- **Grammar and Spelling**: Automatically correct grammar and spelling errors in your content.
- **Multilingual Support**: Translate your text into several languages instantly.
- **Tone Adjustment**: Easily change the tone of your text to match your desired style.
- **Text Summarization**: Summarize lengthy text effortlessly.
- **OpenAI Integration**: Use OpenAI's ChatGPT to generate content for your website.
- **Create Blog Posts**: Create blog posts with AI-generated content.
- **Create social media posts**: Create social media posts with AI-generated content.
- **Create product descriptions**: Create product descriptions with AI-generated content.


## Installation

1. Download the Dima Blocks Ai ZIP file from the WordPress marketplace.
2. In your WordPress dashboard, navigate to **Plugins > Add New > Upload Plugin**.
3. Click on "Choose File" and select the downloaded ZIP file.
4. Click "Install Now" and wait for the installation to complete.
5. Once installed, click on "Activate Plugin".

## Configuration

1. After activating the plugin, navigate to the Dima Blocks Ai settings page.
2. Enter your OpenAI API key to enable the AI features.
3. Adjust the plugin settings to suit your preferences.
4. Save your settings, and you're all set to start using Dima Blocks Ai!

## Usage

1. Edit your WordPress post or page using the block editor.
2. To convert text to blocks, simply highlight the text and click on the Dima Blocks Ai button in the toolbar.
3. Choose the desired block type, and the AI will automatically generate the content.
4. Use the additional AI-powered features like grammar and spelling correction, translation, tone adjustment, and summarization by selecting the appropriate option in the Dima Blocks Ai toolbar.

## Support

For any questions, issues, or feature requests, please visit our support page at [Support URL]. We're always here to help!

## Changelog

### 1.0.0

- Initial release.

## License

This plugin is licensed under the [License Name]. For more information, please visit [License URL].

Elevate your WordPress experience with Dima Blocks Ai - your smart content creation and editing companion!
