<?php
/**
 * Class: dima_blocks_ai_add_settings_page
 * Description: Add Settings Page
 * @since 0.1.0
 * @package dima-blocks-ai
 * @subpackage dima-blocks-ai/admin
 * @version 0.1.0
 * @author: @adeltahri
 */


class dima_blocks_ai_add_settings_page {

    public function __construct() {
        add_action('admin_menu', array($this, 'dima_blocks_ai_add_settings_page'));
    }

    public function dima_blocks_ai_add_settings_page() {
        add_options_page(
            __('Blocks AI Settings', 'dima-blocks-ai'),
            __('Blocks AI', 'dima-blocks-ai'),
            'manage_options',
            'dima-blocks-ai-settings',
            array($this, 'dima_blocks_ai_render_settings_page')
        );
    }

    public function dima_blocks_ai_render_settings_page() {
        ?>
        <div class="wrap dima_block_ai_dashboard_main">
        </div>
        <?php
    }
}

new dima_blocks_ai_add_settings_page();


function dima_blocks_ai_user_has_permission( $user_id, $meta_key, $meta_value, $post_id, $meta_type )
{
    // Check if the user has the required capability (for example, 'edit_posts')
    return current_user_can('edit_posts');
}

function dima_blocks_ai_register_meta()
{
    register_post_meta(
        '', '_dima_blocks_ai_openai_api_key', array(
        'show_in_rest' => true,
        'single' => true,
        'type' => 'string',
        'auth_callback' => 'dima_blocks_ai_user_has_permission',
        ) 
    );

    register_post_meta(
        '', '_dima_blocks_ai_temperature', array(
        'show_in_rest' => true,
        'single' => true,
        'type' => 'number',
        'auth_callback' => 'dima_blocks_ai_user_has_permission',
        ) 
    );

    register_post_meta(
        '', '_dima_blocks_ai_max_tokens', array(
        'show_in_rest' => true,
        'single' => true,
        'type' => 'number',
        'auth_callback' => 'dima_blocks_ai_user_has_permission',
        ) 
    );
}
add_action('init', 'dima_blocks_ai_register_meta');