<?php
/**
 * Plugin Name:       Dima Blocks Ai
 * Description:       Dima Blocks Ai uses NLP and OpenAI to generate Gutenberg blocks from plain text for easy content creation.
 * Requires at least: 6.1
 * Requires PHP:      7.0
 * Version:           0.2.0
 * Author:            PixelDima
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       dima-blocks-ai
 *
 * @package PixelDima
 */

if(! defined('ABSPATH') ) : exit(); 
endif; // No direct access allowed.
/**
* Define Plugins Contants
*/
define('DIMA_BLOCKS_AI_PATH', trailingslashit(plugin_dir_path(__FILE__)));
define('DIMA_BLOCKS_AI_URL', trailingslashit(plugins_url('', __FILE__)));
define('DIMA_BLOCKS_AI_VERSION', '0.1.0');

/**
 * Registers the block using the metadata loaded from the `block.json` file.
 * Behind the scenes, it registers also all assets so they can be enqueued
 * through the block editor in the corresponding context.
 *
 * @see https://developer.wordpress.org/reference/functions/register_block_type/
 */
function create_block_dima_blocks_ai_block_init()
{
    register_block_type(__DIR__ . '/build/text-to-block');
}
add_action('init', 'create_block_dima_blocks_ai_block_init');


register_activation_hook(__FILE__, 'dima_blocks_ai_activation');

function dima_blocks_ai_activation() {
    // Set a transient to indicate that the plugin was just activated.
    set_transient('dima_blocks_ai_activated', 1, 60);
}


add_action('admin_init', 'dima_blocks_ai_redirect_after_activation');

function dima_blocks_ai_redirect_after_activation()
{
    // Check if the transient is set, and if it is, delete it and redirect to the plugin settings page.
    if (get_transient('dima_blocks_ai_activated')) {
        delete_transient('dima_blocks_ai_activated');
        wp_safe_redirect(admin_url('options-general.php?page=dima-blocks-ai-settings'));
        exit;
    }
}

require_once DIMA_BLOCKS_AI_PATH . '/admin/enqueue.php';
require_once DIMA_BLOCKS_AI_PATH . '/admin/settings.php';
require_once DIMA_BLOCKS_AI_PATH . '/admin/class-settings-routes.php';
