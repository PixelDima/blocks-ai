<?php
function dima_blocks_ai_enqueue_admin_scripts()
{
    $screen = get_current_screen();

    if ($screen && $screen->id === 'settings_page_dima-blocks-ai-settings') {
        wp_enqueue_style(
            'dima-blocks-ai-admin',
            DIMA_BLOCKS_AI_URL.'/build/admin/js/style-index.css',
            array(),
            DIMA_BLOCKS_AI_VERSION,
        );
    
        // Enqueue your bundled script.
        wp_enqueue_script(
            'dima-blocks-ai-admin',
            DIMA_BLOCKS_AI_URL.'/build/admin/js/index.js',
            array( 'wp-i18n', 'wp-element', 'wp-plugins', 'wp-components', 'wp-api', 'wp-hooks', 'wp-edit-post', 'lodash', 'wp-block-library', 'wp-block-editor', 'wp-editor', 'jquery' ),
            DIMA_BLOCKS_AI_VERSION,
            true
        );
    }   
}

add_action('admin_enqueue_scripts', 'dima_blocks_ai_enqueue_admin_scripts');


//load enqueue js for editor block
function dima_blocks_ai_enqueue_block_editor_assets()
{
    wp_enqueue_script(
        'dima-blocks-ai-editor',
        DIMA_BLOCKS_AI_URL.'/build/components/editor/editor.js',
        array( 'wp-i18n', 'wp-element', 'wp-plugins', 'wp-components', 'wp-api', 'wp-hooks', 'wp-edit-post', 'lodash', 'wp-block-library', 'wp-block-editor', 'wp-editor', 'jquery' ),
        DIMA_BLOCKS_AI_VERSION,
        true
    );
}
add_action('enqueue_block_editor_assets', 'dima_blocks_ai_enqueue_block_editor_assets');