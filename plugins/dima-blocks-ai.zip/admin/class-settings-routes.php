<?php

class dima_blocks_ai_settings_routes
{

    public function __construct()
    {
        add_action('rest_api_init', array($this, 'register_settings_routes'));
    }

    /**
     * Description: Register the routes for the objects of the controller.
     *
     * @return void
     */
    public function register_settings_routes()
    {
        register_rest_route(
            'dima-blocks-ai/v1',
            '/settings',
            array(
                'methods' => 'GET',
                'callback' => array($this, 'get_settings'),
                'permission_callback' => array($this, 'user_has_permission'),
            )
        );

        register_rest_route(
            'dima-blocks-ai/v1',
            '/settings',
            array(
                'methods' => 'POST',
                'callback' => array($this, 'update_settings'),
                'permission_callback' => array($this, 'user_has_permission'),
            )
        );
        register_rest_route(
            'dima-blocks-ai/v1',
            '/account',
            array(
                'methods' => 'GET',
                'callback' => array($this, 'get_account'),
                'permission_callback' => array($this, 'user_has_permission'),
            )
        );

        register_rest_route(
            'dima-blocks-ai/v1',
            '/account',
            array(
                'methods' => 'POST',
                'callback' => array($this, 'update_account'),
                'permission_callback' => array($this, 'user_has_permission'),
            )
        );
    }

    public function user_has_permission()
    {
        return current_user_can('edit_posts');
    }

    public function get_settings()
    {
        $settings = array(
            'openai_api_key' => get_option('dima_blocks_ai_openai_api_key'),
            'temperature' => get_option('dima_blocks_ai_temperature', 0.9),
            'max_tokens' => get_option('dima_blocks_ai_max_tokens', 1000),
            'license_key' => get_option('dima_blocks_ai_license_key', ''),
            'email_address' => get_option('dima_blocks_ai_email_address', ''),
            'instance_id' => get_option('dima_blocks_ai_instance_id', ''),
        );

        return rest_ensure_response($settings);
    }

    public function update_settings($request)
    {
        $settings = $request->get_json_params();

        update_option('dima_blocks_ai_openai_api_key', $settings['openai_api_key']);
        update_option('dima_blocks_ai_temperature', $settings['temperature']);
        update_option('dima_blocks_ai_max_tokens', $settings['max_tokens']);
 
        return rest_ensure_response('success');
    }

    public function get_account()
    {
        $settings = array(
            'license_key' => get_option('dima_blocks_ai_license_key', ''),
            'email_address' => get_option('dima_blocks_ai_email_address', ''),
            'instance_id' => get_option('dima_blocks_ai_instance_id', ''),
        );
        return rest_ensure_response($settings);
    }

    public function update_account($request)
    {
        $settings = $request->get_json_params();
        if (empty($settings['license_key']) || empty($settings['email_address'])) {
            return rest_ensure_response('error');
        }else {
            update_option('dima_blocks_ai_license_key', $settings['license_key']);
            update_option('dima_blocks_ai_email_address', $settings['email_address']);
            update_option('dima_blocks_ai_instance_id', $settings['instance_id']);
            return rest_ensure_response('success');
        }
    }
}

new dima_blocks_ai_settings_routes();